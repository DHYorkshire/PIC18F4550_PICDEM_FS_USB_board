

void USART_Init(long baud_rate);
char USART_TransmitChar (char out);
char USART_ReceiveChar();
unsigned char getc(void); //keep
void putc(unsigned char c); //keep
void say_hello(void);