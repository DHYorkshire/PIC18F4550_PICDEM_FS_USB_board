#include <xc.h>

const char Message[] = "Hello World 57600 8-N-1";
const char Message2[] ="PICDEM_FS_USB_Demo 30/5/2022";
void USART_Init(long baud_rate)
{
    float temp;
    TRISC6=0;		/* Make Tx pin as output*/
    TRISC7=1;  		/* Make Rx pin as input*/

    BAUDCON = 0x08; /* use 16 bit BRG */
    TXSTA = 0x04; /* TX enabled, select high speed BRG */
    RCSTA = 0x00; /* RX enabled */

    SYNC = 0; /* Asynchronous */
    BRGH =1; // high baud rate
    BRG16=1; // 16 bit mode  
    SPBRGH = 0;
    switch (baud_rate)
    {
                case 19200:
                SPBRGH= 624 >>8;   
                SPBRG = 624 & 0x00FF;
                break;
        
            case 57600:
                SPBRG = 206;
                break;
            case  115200:
                SPBRG = 103;
                break;                  
            case  230800:
                SPBRG = 51;
                break; 
    }            
    /* 9600
     * for 48mhz SYNC=0; BRGH=1 ; BRG16=1; SPBRG = 4998
     * 19200
     * for 48mhz SYNC=0; BRGH=1 ; BRG16=1; SPBRG = 624
     * 57600
     *  for 48mhz SYNC=0; BRGH=1 ; BRG16=1; SPBRG = 206    
     * 115200
     * for 8Mhz SYNC=0; BRGH =1; BRG16=1;  SPBRG =16
       for 16Mhz SYNC=0; BRGH =1; BRG16=1;  SPBRG =34
     * for 48mhz SYNC=0; BRGH=1 ; BRG16=1; SPBRG = 103
     * 230800
     * for 48mhz SYNC=0; BRGH=1 ; BRG16=1; SPBRG = 51
     */

 
    SPEN = 1; /* enable UART serial ports */

    TXEN = 1; //enable transmission
    CREN = 1; //enable reception 
    
    //TXSTA = 0x20;  	/* Enable Transmit(TX) */ 
    //RCSTA = 0x90;  	/* Enable Receive(RX) & Serial */
}

char USART_TransmitChar (char out)
{
   while (TXIF == 0);	/* Wait for transmit interrupt flag*/
   TXREG = out;  	/* Write char data to transmit register */    
}

char USART_ReceiveChar()
{
    while(RCIF==0);      /*wait for receive interrupt flag*/
    if(RCSTAbits.OERR)
    {           
        CREN = 0;
        NOP();
        CREN=1;
    }
    return(RCREG);       /*received in RCREG register and return to main program */
}

unsigned char getc(void) //keep
{
    unsigned char c,d;

    if (!OERR && !FERR)
        {    
        c = RCREG; /* get a character from UART */
        d=  RCREG; /* get a character from UART */
        }
    if (OERR) 
        {
         c = RCREG; /* read twice to clear FIFO */
         c = RCREG;
         CREN = 0; /* clear overrun error */
         CREN = 1;
        }
    return c;
};

void putc(char c) //keep
{
    while (!TXIF);
    TXREG = c;
};

void say_hello(void)
{
 char i; 

 i=0;
while(Message[i] != '\0')
  {
     USART_TransmitChar(Message[i]);
     i++;        
  }
 putc(0x0d);
 putc(0x0a);
 i=0;
 while(Message2[i] != '\0')
  {
     USART_TransmitChar(Message2[i]);
     i++;        
  }
 putc(0x0d);
 putc(0x0a);
}

void say_hi(void)
{
    putc('h');
    putc('i');
    putc(0x0d);
    putc(0x0a);
}
