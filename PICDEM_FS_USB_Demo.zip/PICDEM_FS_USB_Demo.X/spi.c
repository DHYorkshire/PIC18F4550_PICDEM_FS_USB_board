#include <xc.h>
#include <pic18f4550.h>


#define _XTAL_FREQ 4800000


#define CS PORTBbits.RB2     // CS      

char byte1,byte2;
  

void delay(int x){
    for(int j=0;j<x;j++){
        __delay_ms(1);
    };
}

void open_spi()
{
    SSPSTAT = 0b01000000; // SMP  CKE I2C I2C I2C I2C I2C BF
                          // bit 7 1 = Input data sampled at end of data output time
                          //       0 = Input data sampled at middle of data output time (*)
                          // bit 6 1 = Transmit occurs on transition from active to Idle clock state (*)
                         //        0 = Transmit occurs on transition from Idle to active clock state
                        //
    //SSPCON = 0b00100000;
    SSPCON2 = 0b00000000;
    SSPCON1 = 0b00100001;    //  bit 7 WCOL: Write Collision Detect bit (Transmit mode only)
                            //  bit 6 SSPOV: Receive Overflow Indicator bit (slave mode))
                            //  bit 5 SSPEN: Synchronous Serial Port Enable bit
                            //  bit 4 CKP: Clock Polarity Select bit (0))
                            //  0010 = SPI Master mode, clock = FOSC/64
                            //  0001 = SPI Master mode, clock = FOSC/16
                            //  0000 = SPI Master mode, clock = FOSC/4

    /*PORT definition for SPI pins*/    
    TRISBbits.TRISB0 = 1;    /* RB0 as input(SDI) */
    TRISBbits.TRISB1 = 0;     /* RB1 as output(SCK) */
    TRISAbits.TRISA5 = 0;     /* RA5 as a output(SS') */
    TRISCbits.TRISC7 = 0;     /* RC7 as output(SDO) */

    TRISB2 = 0;      /* CS Set as output Port */
    CS = 1;
    
}

void SPI_read(void)
{
     CS=0; 
     SSPBUF= 0x00;          // dummy get
     while(!BF){} 
     byte1 = SSPBUF;
     SSPBUF= 0x00;          // dummy get
     while(!BF){}    
     byte2 = SSPBUF; 
     CS=1;
}

