void delay(int x);
void open_spi();
void SPI_read(void);
void say_hi(void);